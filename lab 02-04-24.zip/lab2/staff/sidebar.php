<div class="list-group list-group-flush mt-4">
                    <a href="index.php" class="list-group-item list-group-item-action py-2 ripple active" aria-current="true">
                        <i class="fas fa-tachometer-alt fa-fw me-3"></i><span>Dashboard</span>
                    </a>
                    <a href="test.php" class="list-group-item list-group-item-action py-2 ripple ">
                        <i class="fas fa-chart-area fa-fw me-3"></i><span>Test</span>
                    </a>
                    <a href="book.php" class="list-group-item list-group-item-action py-2 ripple">
                        <i class="fas fa-users fa-fw me-3"></i><span>Book</span>
                    </a>
                    <a href="appointment.php" class="list-group-item list-group-item-action py-2 ripple ">
                        <i class="fas fa-calendar fa-fw me-3"></i><span>Appointment</span>
                    </a>
                    
                </div>